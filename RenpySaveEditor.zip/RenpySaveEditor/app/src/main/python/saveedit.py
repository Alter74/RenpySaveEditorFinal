"""Núcleo del editor de saves de Ren'Py (lo llama la app Kotlin vía Chaquopy)."""
import ast
import base64
import copy
import copyreg
import hashlib
import io
import json
import os
import pickle
import re
import secrets
import zipfile
import time
import zlib

_STUBS = {}
_state = {}


# ---------------------------------------------------------------- pickle
def _stub_base(name):
    low = name.lower()
    if "list" in low:
        return list
    if "dict" in low or "ordered" in low:
        return dict
    if "set" in low:
        return set
    return object


def _make_stub(module, name):
    """Clase de relleno para objetos de Ren'Py que no existen aquí. Acepta los
    argumentos de construcción (p. ej. PyExpr(texto, archivo, línea)) y los
    conserva para escribirlos igual al guardar."""
    key = (module, name)
    if key in _STUBS:
        return _STUBS[key]
    base = _stub_base(name)

    def __new__(cls, *args, **kwargs):
        if base is object:
            obj = object.__new__(cls)
            obj.__dict__["_newargs"] = args
        else:
            obj = base.__new__(cls)  # list/dict/set: el contenido llega por APPENDS/SETITEMS
        return obj

    def __getnewargs__(self):
        return self.__dict__.get("_newargs", ())

    def __setstate__(self, state):
        if isinstance(state, dict):
            self.__dict__.update(state)
        else:
            self.__dict__["_raw_state"] = state

    def __getstate__(self):
        if "_raw_state" in self.__dict__:
            return self.__dict__["_raw_state"]
        d = {k: v for k, v in self.__dict__.items() if k != "_newargs"}
        return d or None

    def __reduce_ex__(self, protocol):
        # Siempre: NEWOBJ + estado + elementos, igual que escribe Ren'Py. (Sin esto,
        # los set heredan su propio __reduce__ y se perdería el estado original.)
        items = iter(self) if isinstance(self, list) else None
        ditems = iter(self.items()) if isinstance(self, dict) else None
        return (copyreg.__newobj__, (type(self),) + tuple(self.__getnewargs__()),
                self.__getstate__(), items, ditems)

    ns = {"_ref": (module, name), "__new__": __new__, "__getnewargs__": __getnewargs__,
          "__setstate__": __setstate__, "__getstate__": __getstate__,
          "__reduce_ex__": __reduce_ex__, "__reduce__": lambda self: __reduce_ex__(self, 2),
          "__module__": "stub"}
    cls = type(name.split(".")[-1], (base,), ns)
    _STUBS[key] = cls
    return cls


class SaveUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        if module.split(".")[0] in ("renpy", "store", "__main__"):
            return _make_stub(module, name)
        try:
            return super().find_class(module, name)
        except (ImportError, AttributeError):
            return _make_stub(module, name)


class SavePickler(pickle._Pickler):
    def save_global(self, obj, name=None):
        ref = obj.__dict__.get("_ref") if isinstance(obj, type) else None
        if ref:
            self.write(pickle.GLOBAL + ref[0].encode() + b"\n" + ref[1].encode() + b"\n")
            self.memoize(obj)
            return
        super().save_global(obj, name)


def _to_bytes(data):
    try:
        return bytes(data)
    except Exception:
        return bytes(b & 0xFF for b in data)


# ------------------------------------------------- localizar el "log"
def _is_zip(data):
    try:
        return zipfile.is_zipfile(io.BytesIO(data))
    except Exception:
        return False


def _base(name):
    return name.replace("\\", "/").rsplit("/", 1)[-1].lower()


def _find(data, depth=0):
    """Busca el miembro 'log' dentro de un zip, en cualquier carpeta, y si el
    zip contiene otros zips/.save (p. ej. varios saves comprimidos juntos)
    entra en ellos. Devuelve la cadena de nombres [zip1_miembro, ..., 'log']."""
    if depth > 4 or not _is_zip(data):
        return None
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = [i.filename for i in z.infolist() if not i.is_dir()]
        # 1) 'log' en la raíz, 2) 'log' en cualquier carpeta
        for n in names:
            if n == "log":
                return [n]
        for n in sorted(names):
            if _base(n) == "log":
                return [n]
        # 3) archivos anidados: primero .save, luego lo demás
        order = sorted(names, key=lambda n: (not n.lower().endswith(".save"), n.lower()))
        for n in order:
            if _base(n) in ("signatures", "json", "renpy_version", "screenshot.png"):
                continue
            try:
                sub = _find(z.read(n), depth + 1)
            except Exception:
                sub = None
            if sub:
                return [n] + sub
    return None


def _read_chain(data, chain):
    for n in chain:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            data = z.read(n)
    return data


def _count_nested_saves(data):
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            return sum(1 for i in z.infolist()
                       if not i.is_dir() and i.filename.lower().endswith(".save"))
    except Exception:
        return 0


def _rebuild(data, chain, newlog):
    if not chain:
        return newlog
    target = chain[0]
    out = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(data)) as zin, \
            zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            payload = b"" if item.is_dir() else zin.read(item.filename)
            if item.filename == target:
                payload = _rebuild(payload, chain[1:], newlog)
            zout.writestr(item, payload)
    return out.getvalue()


def _unpickle(blob):
    return SaveUnpickler(io.BytesIO(blob)).load()



# ------------------------------------------------------------ firma de saves (Ren'Py)
# Ren'Py firma el «log» (y el persistent) con ECDSA P-256 + SHA-1 (librería python-ecdsa).
# Si el save se modifica sin volver a firmarlo, el juego lo rechaza en silencio.
_P = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
_A = _P - 3
_N = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
_G = (0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296,
      0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5)
_SPKI = bytes.fromhex("3059301306072a8648ce3d020106082a8648ce3d030107034200")
_CURVE_OID = bytes.fromhex("06082a8648ce3d030107")


def _ec_add(p1, p2):
    if p1 is None:
        return p2
    if p2 is None:
        return p1
    x1, y1 = p1
    x2, y2 = p2
    if x1 == x2:
        if (y1 + y2) % _P == 0:
            return None
        lam = (3 * x1 * x1 + _A) * pow(2 * y1, -1, _P) % _P
    else:
        lam = (y2 - y1) * pow(x2 - x1, -1, _P) % _P
    x3 = (lam * lam - x1 - x2) % _P
    return (x3, (lam * (x1 - x3) - y1) % _P)


def _ec_mul(k, pt):
    r = None
    while k:
        if k & 1:
            r = _ec_add(r, pt)
        pt = _ec_add(pt, pt)
        k >>= 1
    return r


def _pub_der(d):
    x, y = _ec_mul(d, _G)
    return _SPKI + b"\x04" + x.to_bytes(32, "big") + y.to_bytes(32, "big")


def _der_len(n):
    if n < 0x80:
        return bytes([n])
    b = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(b)]) + b


def _priv_der(d):
    """Clave privada en DER (SEC1), el mismo formato que usa Ren'Py en security_keys.txt."""
    pub = _pub_der(d)[-65:]
    bitstring = b"\x03" + _der_len(len(pub) + 1) + b"\x00" + pub
    body = (b"\x02\x01\x01" + b"\x04\x20" + d.to_bytes(32, "big")
            + b"\xa0" + _der_len(len(_CURVE_OID)) + _CURVE_OID
            + b"\xa1" + _der_len(len(bitstring)) + bitstring)
    return b"\x30" + _der_len(len(body)) + body


def _der_read(b, i):
    tag = b[i]
    n = b[i + 1]
    i += 2
    if n & 0x80:
        k = n & 0x7F
        n = int.from_bytes(b[i:i + k], "big")
        i += k
    return tag, i, n  # el contenido está en b[i:i+n]


def _parse_priv(der):
    """Extrae el número secreto de una clave privada EC en DER (SEC1 o PKCS#8)."""
    _, i, _ = _der_read(der, 0)                 # SEQUENCE
    t, j, n = _der_read(der, i)                 # versión
    version = int.from_bytes(der[j:j + n], "big")
    k = j + n
    t2, j2, n2 = _der_read(der, k)
    if version == 1 and t2 == 0x04:             # SEC1: OCTET STRING con la clave
        return int.from_bytes(der[j2:j2 + n2], "big")
    if version == 0:                            # PKCS#8: algoritmo + OCTET STRING con SEC1
        t3, j3, n3 = _der_read(der, j2 + n2)
        if t3 == 0x04:
            return _parse_priv(der[j3:j3 + n3])
    raise ValueError("clave privada no reconocida")


def _ecdsa_sign(d, data):
    """Firma estilo python-ecdsa: SHA-1, resultado r||s (64 bytes)."""
    e = int.from_bytes(hashlib.sha1(data).digest(), "big")
    while True:
        k = secrets.randbelow(_N - 1) + 1
        r = _ec_mul(k, _G)[0] % _N
        if r == 0:
            continue
        s = pow(k, -1, _N) * (e + r * d) % _N
        if s:
            return r.to_bytes(32, "big") + s.to_bytes(32, "big")


_KEY_DIR = None
_user_keys = []   # claves de tu security_keys.txt (las que el juego ya acepta)
_app_key = None   # clave propia de la app (el juego pregunta si confías en ella)


def _key_line(d):
    return ("signing-key " + base64.b64encode(_priv_der(d)).decode() + " "
            + base64.b64encode(_pub_der(d)).decode() + "\n")


def _parse_keys_text(text):
    keys = []
    for line in (text or "").splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0] == "signing-key":
            try:
                keys.append(_parse_priv(base64.b64decode(parts[1])))
            except Exception:
                continue
    return keys


def set_dir(path):
    """Carpeta privada de la app, donde se guarda la clave propia."""
    global _KEY_DIR, _app_key
    _KEY_DIR = path
    fn = os.path.join(path, "app_signing_key.txt")
    try:
        if os.path.exists(fn):
            with open(fn, "r") as f:
                ks = _parse_keys_text(f.read())
            if ks:
                _app_key = ks[0]
    except Exception:
        pass


def set_signing_keys(text):
    """Carga las claves de firma de tu security_keys.txt. Devuelve cuántas encontró."""
    global _user_keys
    ks = _parse_keys_text(text)
    if not ks:
        raise ValueError("No encontré ninguna «signing-key» en ese archivo. "
                         "Debe ser el security_keys.txt del juego.")
    _user_keys = ks
    return len(ks)


def clear_signing_keys():
    global _user_keys
    _user_keys = []


def _active_keys():
    global _app_key
    if _user_keys:
        return _user_keys
    if _app_key is None:
        _app_key = secrets.randbelow(_N - 1) + 1
        if _KEY_DIR:
            try:
                with open(os.path.join(_KEY_DIR, "app_signing_key.txt"), "w") as f:
                    f.write(_key_line(_app_key))
            except Exception:
                pass
    return [_app_key]


def key_info():
    ks = _active_keys()
    return json.dumps({"user": len(_user_keys),
                       "pub": base64.b64encode(_pub_der(ks[0])).decode(),
                       "trust_line": "" if _user_keys else
                       "verifying-key " + base64.b64encode(_pub_der(ks[0])).decode()})


def sign_lines(data):
    """Líneas 'signature <clave> <firma>' para `data`, como las escribe Ren'Py."""
    out = b""
    for d in _active_keys():
        out += (b"signature " + base64.b64encode(_pub_der(d)) + b" "
                + base64.b64encode(_ecdsa_sign(d, data)) + b"\n")
    return out


def _resign(zbytes, newlog):
    """Reescribe el archivo «signatures» de un .save con la firma del log nuevo."""
    sigs = sign_lines(newlog)
    out = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(zbytes)) as zin, \
            zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
        seen = False
        for item in zin.infolist():
            if item.filename == "signatures":
                zout.writestr(item, sigs)
                seen = True
            else:
                zout.writestr(item, b"" if item.is_dir() else zin.read(item.filename))
        if not seen:
            zout.writestr("signatures", sigs)
    return out.getvalue()


# ------------------------------------------------------------ helpers
class _Flat:
    """Vista de las variables cuando el save las guarda como claves planas 'store.nombre'
    (así lo hacen Ren'Py 7/8). Leer y escribir aquí modifica el diccionario original."""

    def __init__(self, roots, prefix="store."):
        self._r = roots
        self._p = prefix

    def _full(self, k):
        return self._p + str(k)

    def __getitem__(self, k):
        return self._r[self._full(k)]

    def __setitem__(self, k, v):
        self._r[self._full(k)] = v

    def __contains__(self, k):
        return self._full(k) in self._r

    def __iter__(self):
        n = len(self._p)
        return iter([k[n:] for k in list(self._r) if isinstance(k, str) and k.startswith(self._p)])

    def __len__(self):
        return sum(1 for _ in self)

    def get(self, k, default=None):
        return self._r.get(self._full(k), default)


class _AttrView:
    """Variables de un archivo persistent: son atributos del objeto Persistent."""

    def __init__(self, obj):
        self._d = obj.__dict__

    def __getitem__(self, k):
        return self._d[k]

    def __setitem__(self, k, v):
        self._d[k] = v
        ch = self._d.get("_changed")  # Ren'Py anota cuándo cambió cada valor
        if isinstance(ch, dict):
            ch[k] = time.time()

    def __contains__(self, k):
        return k in self._d and k != "_newargs"

    def __iter__(self):
        return iter([k for k in list(self._d) if k != "_newargs"])

    def __len__(self):
        return len([k for k in self._d if k != "_newargs"])

    def get(self, k, default=None):
        return self._d.get(k, default)


def _store():
    if _state.get("raw") == "persistent":
        return _AttrView(_state["roots"]["__persistent__"])
    roots = _state["roots"]
    inner = roots.get("store")
    if isinstance(inner, dict):          # formato antiguo: un diccionario 'store'
        return inner
    return _Flat(roots)                  # formato normal: claves 'store.nombre'


def _editable(v):
    if isinstance(v, set) and "_raw_state" in getattr(v, "__dict__", {}):
        return False  # conjuntos internos de Ren'Py (RevertableSet): se conservan tal cual
    return v is None or isinstance(v, (bool, int, float, str, list, dict, set))


def _kind(v):
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, (int, float)):
        return "num"
    if isinstance(v, str):
        return "str"
    return "other"


def _row(k, v):
    try:
        r = repr(v)
    except Exception:
        r = "<?>"
    return {"name": str(k), "type": type(v).__name__, "kind": _kind(v),
            "value": r if len(r) < 160 else r[:160] + "…",
            "editable": _editable(v)}


def _push(name, cur):
    try:
        snap = copy.deepcopy(cur)
    except Exception:
        try:
            snap = copy.copy(cur)
        except Exception:
            snap = cur
    h = _state.setdefault("hist", [])
    h.append((name, snap))
    del h[:-300]


def _short(v):
    try:
        r = repr(v)
    except Exception:
        r = "<?>"
    return r if len(r) <= 60 else r[:60] + "…"


def _log(name, old):
    """Anota el cambio en el historial (los cambios seguidos de la misma variable se agrupan)."""
    new = _short(_store()[name])
    L = _state.setdefault("changes", [])
    if L and L[-1]["name"] == name:
        L[-1]["new"] = new
        L[-1]["n"] += 1
    else:
        L.append({"name": name, "old": old, "new": new, "n": 1, "t": time.strftime("%H:%M")})


def _assign(name, new):
    """Asigna conservando la identidad de listas/dicts/sets (por si el save
    comparte la misma referencia en varios sitios)."""
    store = _store()
    cur = store[name]
    if isinstance(cur, list) and isinstance(new, (list, tuple)):
        cur[:] = list(new)
    elif isinstance(cur, dict) and isinstance(new, dict):
        cur.clear(); cur.update(new)
    elif isinstance(cur, set) and isinstance(new, (set, list, tuple)):
        cur.clear(); cur.update(new)
    else:
        store[name] = new


# ---------------------------------------------------- API usada desde Kotlin
_XOM_FORMATS = [(True, (", ", ": ")), (False, (", ", ": ")), (True, (",", ":")), (False, (",", ":"))]


def _try_xom(data):
    """Saves en JSON tipado: {"variable": {"__type": "int", "value": 3}, ...} (archivos .xom).
    Devuelve (dict, bom) o None si no es ese formato."""
    if data.lstrip(b"\xef\xbb\xbf \t\r\n")[:1] != b"{":
        return None
    try:
        text = data.decode("utf-8-sig")
        j = json.loads(text)
    except Exception:
        return None
    if isinstance(j, dict) and j and all(
            isinstance(v, dict) and "__type" in v and "value" in v for v in j.values()):
        return j, data.startswith(b"\xef\xbb\xbf"), text
    return None


def _load_xom(data, found):
    j, bom, text = found
    fmt = _XOM_FORMATS[0]
    for cand in _XOM_FORMATS:  # elegimos el formato que reproduce el archivo original
        if json.dumps(j, ensure_ascii=cand[0], separators=cand[1]) == text:
            fmt = cand
            break
    store = {k: v["value"] for k, v in j.items()}
    meta = {k: {kk: vv for kk, vv in v.items() if kk != "value"} for k, v in j.items()}
    _state.clear()
    _state.update(orig=data, chain=[], raw="xom", roots={"store": store}, log=None,
                  hist=[], changes=[], xom_meta=meta, xom_bom=bom, xom_fmt=fmt)
    return json.dumps({"n": len(store), "inner": "", "saves": 0})


def _export_xom():
    meta = _state["xom_meta"]
    store = _state["roots"]["store"]
    out = {}
    for k, v in store.items():
        entry = dict(meta.get(k, {"__type": type(v).__name__}))
        entry["value"] = v
        out[k] = entry
    ascii_, sep = _state["xom_fmt"]
    raw = json.dumps(out, ensure_ascii=ascii_, separators=sep).encode("utf-8")
    return (b"\xef\xbb\xbf" + raw) if _state["xom_bom"] else raw


def load(data):
    """Devuelve JSON: {"n": nº de variables, "inner": ruta interna, "saves": nº de .save}"""
    data = _to_bytes(data)
    xom = _try_xom(data)
    if xom is not None:
        return _load_xom(data, xom)
    chain = _find(data)
    raw_mode = None
    if chain:
        blob = _read_chain(data, chain)
    else:
        # No es zip (o no trae 'log'): ¿pickle suelto, quizá comprimido con zlib?
        blob = data
        raw_mode = "plain"
        if not _is_zip(data):
            try:
                blob = zlib.decompressobj().decompress(data)  # ignora la firma que va al final
                raw_mode = "zlib"
            except Exception:
                pass
        chain = []
    try:
        parsed = _unpickle(blob)
        if raw_mode == "zlib" and not (isinstance(parsed, tuple) and len(parsed) == 2):
            # Un archivo «persistent» de Ren'Py: un solo objeto Persistent comprimido
            _state.clear()
            _state.update(orig=data, chain=[], raw="persistent", roots={"__persistent__": parsed},
                          log=None, hist=[], changes=[])
            return json.dumps({"n": len(_store()), "inner": "", "saves": 0})
        roots, rlog = parsed
        if not isinstance(roots, dict):
            raise ValueError("roots")
    except Exception as e:
        if chain:  # sí había un «log», pero no se pudo leer su contenido
            raise ValueError("No pude leer el contenido del save (%s: %s)." % (type(e).__name__, e))
        if _is_zip(data):
            raise ValueError("El zip no contiene ningún save de Ren'Py (no encontré el archivo «log»).")
        raise ValueError("No reconozco este archivo. Usa un .save de Ren'Py, un .zip con saves o un .xom.")
    _state.clear()
    _state.update(orig=data, chain=chain, raw=raw_mode, roots=roots, log=rlog, hist=[], changes=[])
    return json.dumps({"n": len(_store()),
                       "inner": " → ".join(chain[:-1]) if len(chain) > 1 else "",
                       "saves": _count_nested_saves(data)})


def original():
    return _state["orig"]


def is_wrapped():
    """True si el save venía dentro de un .zip (el resultado se guarda como .save suelto)."""
    return len(_state.get("chain") or []) > 1


def suggest_name():
    """Nombre sugerido para el .save suelto cuando venía dentro de un .zip ('' si no aplica)."""
    chain = _state.get("chain") or []
    if len(chain) < 2:
        return ""
    name = chain[-2].replace("\\", "/").rsplit("/", 1)[-1]
    return name if "." in name else name + ".save"


def list_vars(query, kind="all", hide_private=True, only_editable=True):
    q = (query or "").lower()
    out = []
    store = _store()
    for k in sorted(store, key=str):
        v = store[k]
        if hide_private and str(k).startswith("_"):
            continue
        if only_editable and not _editable(v):
            continue
        row = _row(k, v)
        if kind != "all" and row["kind"] != kind:
            continue
        if q and q not in row["name"].lower() and q not in row["value"].lower():
            continue
        out.append(row)
    return json.dumps(out)


def get_row(name):
    return json.dumps(_row(name, _store()[name]))


def get_repr(name):
    return repr(_store()[name])


def get_raw(name):
    """Texto para el cuadro de edición: las cadenas sin comillas, el resto como Python."""
    v = _store()[name]
    return v if isinstance(v, str) else repr(v)


def adjust(name, direction, step=1):
    """Suma/resta `step` (los float avanzan step*0.1). Devuelve '' o un error."""
    try:
        cur = _store()[name]
        if isinstance(cur, bool) or not isinstance(cur, (int, float)):
            return "No es un número."
        step = int(step) if isinstance(cur, int) else step * 0.1
        _push(name, cur)
        old = _short(cur)
        new = cur + step * (1 if direction > 0 else -1)
        if isinstance(cur, float):
            new = round(new, 6)
        _assign(name, new)
        _log(name, old)
    except Exception as e:
        return str(e)
    return ""


def set_bool(name, value):
    try:
        _push(name, _store()[name])
        old = _short(_store()[name])
        _assign(name, bool(value))
        _log(name, old)
    except Exception as e:
        return str(e)
    return ""


def set_value(name, text):
    """Pone el valor escrito con el teclado. Devuelve '' si todo bien o un mensaje."""
    store = _store()
    cur = store[name]
    try:
        if isinstance(cur, bool):
            t = text.strip().lower()
            if t in ("true", "1", "si", "sí", "yes", "verdadero"):
                new = True
            elif t in ("false", "0", "no", "falso"):
                new = False
            else:
                return "Escribe True o False."
        elif isinstance(cur, int):
            t = text.strip().replace(",", "").replace(" ", "")
            try:
                new = int(t)
            except ValueError:
                return "Escribe un número entero (ej. 1500)."
        elif isinstance(cur, float):
            t = text.strip().replace(",", ".").replace(" ", "")
            try:
                new = float(t)
            except ValueError:
                return "Escribe un número (ej. 3.5)."
        elif isinstance(cur, str):
            new = text  # texto tal cual, sin comillas
        else:
            try:
                new = ast.literal_eval(text.strip())
            except Exception:
                return "Valor no válido. Usa sintaxis Python: 10, 'texto', [1, 2], {'a': 1}"
            if isinstance(cur, list) and not isinstance(new, (list, tuple)):
                return "Debe ser una lista, ej. [1, 2, 3]."
            if isinstance(cur, dict) and not isinstance(new, dict):
                return "Debe ser un diccionario, ej. {'a': 1}."
            if isinstance(cur, set) and not isinstance(new, (set, list, tuple)):
                return "Debe ser un conjunto, ej. {1, 2}."
        _push(name, cur)
        old = _short(cur)
        _assign(name, new)
        _log(name, old)
    except Exception as e:
        return str(e)
    return ""


set_var = set_value  # compatibilidad con la versión anterior


def undo():
    """Deshace el último cambio. Devuelve el nombre de la variable o ''."""
    h = _state.get("hist") or []
    if not h:
        return ""
    name, old = h.pop()
    try:
        _assign(name, old)
    except Exception:
        return ""
    L = _state.get("changes") or []
    if L and L[-1]["name"] == name:
        L[-1]["n"] -= 1
        if L[-1]["n"] <= 0:
            L.pop()
        else:
            L[-1]["new"] = _short(_store()[name])
    return name


def changes():
    """Historial de la sesión (más reciente primero) como JSON."""
    return json.dumps(list(reversed(_state.get("changes") or [])))


def undo_all():
    n = 0
    while undo():
        n += 1
    return n


def history_size():
    return len(_state.get("hist") or [])


def export():
    if _state.get("raw") == "xom":
        return _export_xom()
    buf = io.BytesIO()
    if _state.get("raw") == "persistent":
        SavePickler(buf, protocol=2).dump(_state["roots"]["__persistent__"])
        raw = buf.getvalue()
        return zlib.compress(raw, 3) + sign_lines(raw)  # el persistent lleva la firma al final
    SavePickler(buf, protocol=2).dump((_state["roots"], _state["log"]))
    newlog = buf.getvalue()
    chain = _state.get("chain") or []
    if chain:
        # El juego solo lee el .save suelto (con «log» en la raíz). Si venía dentro de un
        # .zip, devolvemos únicamente el save de dentro, ya modificado, sin la envoltura.
        inner = _read_chain(_state["orig"], chain[:-1]) if len(chain) > 1 else _state["orig"]
        res = _rebuild(inner, [chain[-1]], newlog)
        # Sin una firma válida, Ren'Py no carga el save (se queda en la lista de partidas)
        return _resign(res, newlog) if chain[-1] == "log" else res
    if _state.get("raw") == "zlib":
        return zlib.compress(newlog)
    return newlog


def unlock_gallery():
    """Desbloquea la galería. En un save: locked=False en cada escena (gallery00, gallery01…).
    En un persistent: item_unlocked_N = True. Devuelve JSON {"n": cuántos cambió}."""
    n = 0
    if _state.get("raw") == "persistent":
        d = _state["roots"]["__persistent__"].__dict__
        idx = [int(k[14:]) for k in d if k.startswith("item_unlocked_") and k[14:].isdigit()]
        ch = d.get("_changed") if isinstance(d.get("_changed"), dict) else None
        for i in range(max(idx + [16]) + 1):
            k = "item_unlocked_%d" % i
            if d.get(k) is not True:
                d[k] = True
                if ch is not None:
                    ch[k] = time.time()
                n += 1
    elif _state.get("raw") != "xom":
        store = _store()
        for name in sorted(store, key=str):
            if re.fullmatch(r"gallery\d+", str(name)):
                obj = store[name]
                dd = getattr(obj, "__dict__", None)
                if dd is not None and dd.get("locked") is not False and "locked" in dd:
                    dd["locked"] = False
                    n += 1
    return json.dumps({"n": n})
