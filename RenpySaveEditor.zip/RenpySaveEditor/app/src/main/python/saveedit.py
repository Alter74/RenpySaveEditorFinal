"""Núcleo del editor de saves de Ren'Py (lo llama la app Kotlin vía Chaquopy)."""
import ast
import copy
import io
import json
import pickle
import zipfile
import time
import zlib

_STUBS = {}
_state = {}


# ---------------------------------------------------------------- pickle
def _stub_base(name):
    low = name.lower()
    if "list" in low:
        return list
    if "dict" in low or "ordered" in low:
        return dict
    if "set" in low:
        return set
    return object


def _make_stub(module, name):
    key = (module, name)
    if key in _STUBS:
        return _STUBS[key]

    def __setstate__(self, state):
        if isinstance(state, dict):
            self.__dict__.update(state)
        else:
            self.__dict__["_raw_state"] = state

    def __getstate__(self):
        if "_raw_state" in self.__dict__:
            return self.__dict__["_raw_state"]
        return dict(self.__dict__)

    ns = {"_ref": (module, name), "__setstate__": __setstate__,
          "__getstate__": __getstate__, "__module__": "stub"}
    cls = type(name.split(".")[-1], (_stub_base(name),), ns)
    _STUBS[key] = cls
    return cls


class SaveUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        if module.split(".")[0] in ("renpy", "store", "__main__"):
            return _make_stub(module, name)
        try:
            return super().find_class(module, name)
        except (ImportError, AttributeError):
            return _make_stub(module, name)


class SavePickler(pickle._Pickler):
    def save_global(self, obj, name=None):
        ref = obj.__dict__.get("_ref") if isinstance(obj, type) else None
        if ref:
            self.write(pickle.GLOBAL + ref[0].encode() + b"\n" + ref[1].encode() + b"\n")
            self.memoize(obj)
            return
        super().save_global(obj, name)


def _to_bytes(data):
    try:
        return bytes(data)
    except Exception:
        return bytes(b & 0xFF for b in data)


# ------------------------------------------------- localizar el "log"
def _is_zip(data):
    try:
        return zipfile.is_zipfile(io.BytesIO(data))
    except Exception:
        return False


def _base(name):
    return name.replace("\\", "/").rsplit("/", 1)[-1].lower()


def _find(data, depth=0):
    """Busca el miembro 'log' dentro de un zip, en cualquier carpeta, y si el
    zip contiene otros zips/.save (p. ej. varios saves comprimidos juntos)
    entra en ellos. Devuelve la cadena de nombres [zip1_miembro, ..., 'log']."""
    if depth > 4 or not _is_zip(data):
        return None
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = [i.filename for i in z.infolist() if not i.is_dir()]
        # 1) 'log' en la raíz, 2) 'log' en cualquier carpeta
        for n in names:
            if n == "log":
                return [n]
        for n in sorted(names):
            if _base(n) == "log":
                return [n]
        # 3) archivos anidados: primero .save, luego lo demás
        order = sorted(names, key=lambda n: (not n.lower().endswith(".save"), n.lower()))
        for n in order:
            if _base(n) in ("signatures", "json", "renpy_version", "screenshot.png"):
                continue
            try:
                sub = _find(z.read(n), depth + 1)
            except Exception:
                sub = None
            if sub:
                return [n] + sub
    return None


def _read_chain(data, chain):
    for n in chain:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            data = z.read(n)
    return data


def _count_nested_saves(data):
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            return sum(1 for i in z.infolist()
                       if not i.is_dir() and i.filename.lower().endswith(".save"))
    except Exception:
        return 0


def _rebuild(data, chain, newlog):
    if not chain:
        return newlog
    target = chain[0]
    out = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(data)) as zin, \
            zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            payload = b"" if item.is_dir() else zin.read(item.filename)
            if item.filename == target:
                payload = _rebuild(payload, chain[1:], newlog)
            zout.writestr(item, payload)
    return out.getvalue()


def _unpickle(blob):
    return SaveUnpickler(io.BytesIO(blob)).load()


# ------------------------------------------------------------ helpers
def _store():
    return _state["roots"].get("store", {})


def _editable(v):
    return v is None or isinstance(v, (bool, int, float, str, list, dict, set))


def _kind(v):
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, (int, float)):
        return "num"
    if isinstance(v, str):
        return "str"
    return "other"


def _row(k, v):
    try:
        r = repr(v)
    except Exception:
        r = "<?>"
    return {"name": str(k), "type": type(v).__name__, "kind": _kind(v),
            "value": r if len(r) < 160 else r[:160] + "…",
            "editable": _editable(v)}


def _push(name, cur):
    try:
        snap = copy.deepcopy(cur)
    except Exception:
        try:
            snap = copy.copy(cur)
        except Exception:
            snap = cur
    h = _state.setdefault("hist", [])
    h.append((name, snap))
    del h[:-300]


def _short(v):
    try:
        r = repr(v)
    except Exception:
        r = "<?>"
    return r if len(r) <= 60 else r[:60] + "…"


def _log(name, old):
    """Anota el cambio en el historial (los cambios seguidos de la misma variable se agrupan)."""
    new = _short(_store()[name])
    L = _state.setdefault("changes", [])
    if L and L[-1]["name"] == name:
        L[-1]["new"] = new
        L[-1]["n"] += 1
    else:
        L.append({"name": name, "old": old, "new": new, "n": 1, "t": time.strftime("%H:%M")})


def _assign(name, new):
    """Asigna conservando la identidad de listas/dicts/sets (por si el save
    comparte la misma referencia en varios sitios)."""
    store = _store()
    cur = store[name]
    if isinstance(cur, list) and isinstance(new, (list, tuple)):
        cur[:] = list(new)
    elif isinstance(cur, dict) and isinstance(new, dict):
        cur.clear(); cur.update(new)
    elif isinstance(cur, set) and isinstance(new, (set, list, tuple)):
        cur.clear(); cur.update(new)
    else:
        store[name] = new


# ---------------------------------------------------- API usada desde Kotlin
def load(data):
    """Devuelve JSON: {"n": nº de variables, "inner": ruta interna, "saves": nº de .save}"""
    data = _to_bytes(data)
    chain = _find(data)
    raw_mode = None
    if chain:
        blob = _read_chain(data, chain)
    else:
        # No es zip (o no trae 'log'): ¿pickle suelto, quizá comprimido con zlib?
        blob = data
        raw_mode = "plain"
        if not _is_zip(data):
            try:
                blob = zlib.decompress(data)
                raw_mode = "zlib"
            except Exception:
                pass
        chain = []
    try:
        parsed = _unpickle(blob)
        roots, rlog = parsed
        if not isinstance(roots, dict):
            raise ValueError("roots")
    except Exception:
        if _is_zip(data):
            raise ValueError("El zip no contiene ningún save de Ren'Py (no encontré el archivo «log»).")
        raise ValueError("Este archivo no parece un save de Ren'Py (.save).")
    _state.clear()
    _state.update(orig=data, chain=chain, raw=raw_mode, roots=roots, log=rlog, hist=[], changes=[])
    return json.dumps({"n": len(roots.get("store", {})),
                       "inner": " → ".join(chain[:-1]) if len(chain) > 1 else "",
                       "saves": _count_nested_saves(data)})


def original():
    return _state["orig"]


def list_vars(query, kind="all", hide_private=True, only_editable=True):
    q = (query or "").lower()
    out = []
    store = _store()
    for k in sorted(store, key=str):
        v = store[k]
        if hide_private and str(k).startswith("_"):
            continue
        if only_editable and not _editable(v):
            continue
        row = _row(k, v)
        if kind != "all" and row["kind"] != kind:
            continue
        if q and q not in row["name"].lower() and q not in row["value"].lower():
            continue
        out.append(row)
    return json.dumps(out)


def get_row(name):
    return json.dumps(_row(name, _store()[name]))


def get_repr(name):
    return repr(_store()[name])


def get_raw(name):
    """Texto para el cuadro de edición: las cadenas sin comillas, el resto como Python."""
    v = _store()[name]
    return v if isinstance(v, str) else repr(v)


def adjust(name, direction, step=1):
    """Suma/resta `step` (los float avanzan step*0.1). Devuelve '' o un error."""
    try:
        cur = _store()[name]
        if isinstance(cur, bool) or not isinstance(cur, (int, float)):
            return "No es un número."
        step = int(step) if isinstance(cur, int) else step * 0.1
        _push(name, cur)
        old = _short(cur)
        new = cur + step * (1 if direction > 0 else -1)
        if isinstance(cur, float):
            new = round(new, 6)
        _assign(name, new)
        _log(name, old)
    except Exception as e:
        return str(e)
    return ""


def set_bool(name, value):
    try:
        _push(name, _store()[name])
        old = _short(_store()[name])
        _assign(name, bool(value))
        _log(name, old)
    except Exception as e:
        return str(e)
    return ""


def set_value(name, text):
    """Pone el valor escrito con el teclado. Devuelve '' si todo bien o un mensaje."""
    store = _store()
    cur = store[name]
    try:
        if isinstance(cur, bool):
            t = text.strip().lower()
            if t in ("true", "1", "si", "sí", "yes", "verdadero"):
                new = True
            elif t in ("false", "0", "no", "falso"):
                new = False
            else:
                return "Escribe True o False."
        elif isinstance(cur, int):
            t = text.strip().replace(",", "").replace(" ", "")
            try:
                new = int(t)
            except ValueError:
                return "Escribe un número entero (ej. 1500)."
        elif isinstance(cur, float):
            t = text.strip().replace(",", ".").replace(" ", "")
            try:
                new = float(t)
            except ValueError:
                return "Escribe un número (ej. 3.5)."
        elif isinstance(cur, str):
            new = text  # texto tal cual, sin comillas
        else:
            try:
                new = ast.literal_eval(text.strip())
            except Exception:
                return "Valor no válido. Usa sintaxis Python: 10, 'texto', [1, 2], {'a': 1}"
            if isinstance(cur, list) and not isinstance(new, (list, tuple)):
                return "Debe ser una lista, ej. [1, 2, 3]."
            if isinstance(cur, dict) and not isinstance(new, dict):
                return "Debe ser un diccionario, ej. {'a': 1}."
            if isinstance(cur, set) and not isinstance(new, (set, list, tuple)):
                return "Debe ser un conjunto, ej. {1, 2}."
        _push(name, cur)
        old = _short(cur)
        _assign(name, new)
        _log(name, old)
    except Exception as e:
        return str(e)
    return ""


set_var = set_value  # compatibilidad con la versión anterior


def undo():
    """Deshace el último cambio. Devuelve el nombre de la variable o ''."""
    h = _state.get("hist") or []
    if not h:
        return ""
    name, old = h.pop()
    try:
        _assign(name, old)
    except Exception:
        return ""
    L = _state.get("changes") or []
    if L and L[-1]["name"] == name:
        L[-1]["n"] -= 1
        if L[-1]["n"] <= 0:
            L.pop()
        else:
            L[-1]["new"] = _short(_store()[name])
    return name


def changes():
    """Historial de la sesión (más reciente primero) como JSON."""
    return json.dumps(list(reversed(_state.get("changes") or [])))


def undo_all():
    n = 0
    while undo():
        n += 1
    return n


def history_size():
    return len(_state.get("hist") or [])


def export():
    buf = io.BytesIO()
    SavePickler(buf, protocol=2).dump((_state["roots"], _state["log"]))
    newlog = buf.getvalue()
    chain = _state.get("chain") or []
    if chain:
        return _rebuild(_state["orig"], chain, newlog)
    if _state.get("raw") == "zlib":
        return zlib.compress(newlog)
    return newlog
